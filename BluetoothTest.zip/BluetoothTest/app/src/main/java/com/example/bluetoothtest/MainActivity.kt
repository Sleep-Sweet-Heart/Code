package com.example.bluetoothtest

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    //toast message function
    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private val REQUEST_ENABLE_BT = 1
    private val REQUEST_DISCOVER_BT = 2

    lateinit var mStatusBlueTv: TextView
    lateinit var mPairedTv: TextView
    lateinit var mBlueIv: ImageView
    lateinit var mOnBtn: Button
    lateinit var mOffBtn: Button
    lateinit var mDiscoverBtn: Button
    lateinit var mPairedBtn: Button

    lateinit var mBlueAdapter: BluetoothAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mStatusBlueTv = findViewById(R.id.statusBluetoothTv)
        mPairedTv = findViewById(R.id.pairedTv)
        mBlueIv = findViewById(R.id.bluetoothIv)
        mOnBtn = findViewById(R.id.onBtn)
        mOffBtn = findViewById(R.id.offBtn)
        mDiscoverBtn = findViewById(R.id.discoverableBtn)
        mPairedBtn = findViewById(R.id.pairedBtn)

        //adapter
        mBlueAdapter = BluetoothAdapter.getDefaultAdapter()

        //check if bluetooth is avaible or not
        if (mBlueAdapter == null) {
            mStatusBlueTv.text = "Bluetooth is not available"
        } else {
            mStatusBlueTv.text = "Bluetooth is available"
        }

        //if bluetooth is enabled, set image according to bluetooth status(on/off)
        if (mBlueAdapter.isEnabled) {
            //bluetooth is on
            mBlueIv.setImageResource(R.drawable.ic_action_on)
        } else {
            //bluetooth is off
            mBlueIv.setImageResource(R.drawable.ic_action_off)
        }

        //on btn click
        mOnBtn.setOnClickListener {
            if (mBlueAdapter.isEnabled) {
                showToast("Bluetooth is already on")
            } else {
                showToast("Turning On Bluetooth...")
                //intent to on bluetooth
                val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivityForResult(intent, REQUEST_ENABLE_BT)
            }
        }

        //off btn click
        mOffBtn.setOnClickListener {
            if (!mBlueAdapter.isEnabled) {
                showToast("Bluetooth is already off")
            } else {
                mBlueAdapter.disable()
                mBlueIv.setImageResource(R.drawable.ic_action_off)
                showToast("Bluetooth turned off")
            }
        }

        //discover bluetooth btn click
        mDiscoverBtn.setOnClickListener {
            if (!mBlueAdapter.isDiscovering) {
                showToast("Making your device discoverable")
                val intent = Intent(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE))
            }
        }

        //get paired devices btn click
        mPairedBtn.setOnClickListener {
            if (mBlueAdapter.isEnabled) {
                pairedTv.text = "Paired Devices"
                val devices = mBlueAdapter.bondedDevices
                for (device in devices){
                    val deviceName = device.name
                    val deviceAddress = device
                    pairedTv.append("\nDevice: $deviceName , $device")
                }
                showToast("Bluetooth is already off")
            } else {
                showToast("Turn on bluetooth first")
            }
        }
    }

    override protected fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQUEST_ENABLE_BT ->
                if(resultCode == Activity.RESULT_OK){
                    //bluetooth is on
                    mBlueIv.setImageResource(R.drawable.ic_action_on)
                    showToast("Bluetooth is on");
                }
                else {
                //user denied to turn bluetooth on
                showToast("couldn't on bluetooth");
                }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
